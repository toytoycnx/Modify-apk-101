# รายการแพตช์ (v8)

## AndroidManifest
- เพิ่ม LEANBACK_LAUNCHER ให้ SplashActivity, banner, uses-feature (touchscreen/leanback/กล้อง/ไมค์/โทรศัพท์/GPS/บลูทูธ) required=false
- activity ที่ล็อกแนวตั้ง -> ไม่ล็อก
- targetSdkVersion 34 (ไฟล์ target34) หรือ 33 (ไฟล์ target33)

## โค้ด (dex)
- classes5.dex  `y9/e.i` (เช็กโหมดทีวี) และ `y9/e.o` (เช็กอีมูเลเตอร์) คืนค่า false เสมอ
- classes4.dex  `BaseActivity.onCreate` เดิมล็อกแนวตั้ง (ยกเว้น SDK 26) -> เปลี่ยนเป็น UNSPECIFIED
- classes3.dex  VideoPlayDetailActivity
  - `onStart` เรียก `insertVideoShare` (ใช้เมธอดที่ไม่มีใครเรียกมาเป็นที่วางโค้ด) ซึ่งเรียก `onConfigurationChanged(config ปัจจุบัน)` เพื่อสลับเป็นโหมดเต็มจอเหมือนหมุนจอ
  - `onBackPressed` ออกจากหน้าเสมอ (ข้ามตรรกะออกจากโหมดเต็มจอ)
  - `MainActivity.onKeyDown` เอา `System.exit(0)` ออก
  - `PlayerControlView.E/G` (ซ่อนแถบควบคุม) เป็น no-op
- classes.dex   `VideoPlayerView$c.onClick` ปุ่มย้อนกลับในตัวเล่นเรียก `Activity.onBackPressed` เสมอ
- **ห้ามใส่** โค้ดบังคับโฟกัสตัวเล่น (requestFocus/setDescendantFocusability ใน hook) ทำให้แอปแครชตอนเข้าหน้าวิดีโอ (v7)

## Layout / resource
- `res/layout`: ปลดล็อก descendantFocusability (fragment_home, activity_video_play_detail, activity_download_video, pop_layout_video_detail_tv_set_num), ใส่ foreground+focusable ให้รายการ item_* และ view ที่ผูกการกด, ปุ่ม "เสียงและคำบรรยาย" ให้มองเห็น
- ซ่อน: ไอคอน cast (iv_lelink_*), แบตเตอรี่ (battery), ปุ่ม VIP (tv_openvip_horizontal), ดาวน์โหลด (iv_download ในหน้าวิดีโอและหน้าแรก), รายการโปรด (iv_collection)
- `res/drawable/bg_home_special_list_item4.xml` ถูกเขียนทับเป็นกรอบโฟกัสสีขาว (drawable เดิมไม่มีใครใช้)
- `resources.arsc` เปลี่ยนสี 20 ค่าเป็นธีม Midnight Violet (ดู `tools/palette.py`) ต้องเก็บแบบ stored ไม่บีบอัด ใน APK
