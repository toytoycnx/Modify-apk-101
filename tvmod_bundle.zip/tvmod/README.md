# TV Mod - ชุดสร้าง Movie_TV.apk (เทียบเท่า v8)

## สิ่งที่ต้องมี
- Python 3.9+ และ `pip install cryptography`
- ไฟล์ APK ต้นฉบับ `Movie__1__2.apk` (ตัวที่คุณอัปโหลดตอนแรก ไม่ได้ใส่มาในนี้)

## สร้าง APK
```
python build.py Movie__1__2.apk AndroidManifest.target34.xml Movie_TV_v8.apk
python build.py Movie__1__2.apk AndroidManifest.target33.xml Movie_TV_v8_target33.apk
```
ผลลัพธ์ติดตั้งทับ v2-v8 ที่ติดตั้งไว้ได้เลย เพราะใช้คีย์เซ็นชุดเดียวกัน (`sign_key.pem`, `sign_cert.der`)

## โครงสร้าง
- `build.py`  แพ็ก APK ใหม่ นำไฟล์ใน `patches/` ไปแทนที่ในต้นฉบับ แล้วเซ็นแบบ v1+v2 (เก็บ alignment ของไฟล์ .so และ resources.arsc)
- `patches/`  ไฟล์ที่แก้แล้ว วางตามพาธใน APK (classes*.dex, resources.arsc, res/layout/*.xml, res/drawable/...)
- `AndroidManifest.target34.xml / target33.xml`  manifest ที่แก้แล้ว
- `tools/`  สคริปต์ที่ใช้วิเคราะห์/สร้างแพตช์ (ตัวแยก AXML, ตัวอ่าน dex, ตัวถอดโค้ด Dalvik แบบง่าย) ใช้เป็นข้อมูลอ้างอิง สคริปต์บางตัวมีพาธของเครื่องเดิมอยู่ ต้องปรับพาธก่อนใช้
- `PATCHES.md`  รายการว่าแก้อะไรไปบ้างและแก้ตรงไหน

## ข้อควรระวัง
- **`sign_key.pem` เป็นคีย์ส่วนตัวที่ใช้เซ็นแอปนี้** เก็บไว้เป็นความลับ ใครมีไฟล์นี้จะทำ APK ที่ติดตั้งทับแอปของคุณได้ ห้ามแชร์
- ถ้าทำ APK ด้วยคีย์ใหม่ ต้องถอนการติดตั้งตัวเดิมก่อน และข้อมูลในแอปจะหาย
