import sys; sys.path.insert(0,'/home/claude/w')
import axml
from axml import *
def make():
    pool=StringPool.__new__(StringPool); pool.utf8=False; pool.flags=0
    attrs=[('state_focused',0x0101009c),('width',0x01010159),('shape',0x0101019a),('color',0x010101a5),('radius',0x010101a8)]
    pool.strings=[a for a,_ in attrs]+['android',NS_ANDROID,'selector','item','solid','stroke','corners','shape']
    # 'shape' element name vs attr name share same string -> reuse index of attr 'shape'
    pool.strings=[a for a,_ in attrs]+['android',NS_ANDROID,'selector','item','solid','stroke','corners']
    resmap=[r for _,r in attrs]
    S=pool.strings; ix=S.index
    ANS=ix(NS_ANDROID)
    def A(name,typ,data): return Attr(ANS,ix(name),-1,typ,data)
    L=[0]
    def st(name,attrs_): L[0]+=1; return dict(t=RES_XML_START_EL,line=L[0],ns=-1,name=ix(name),attrs=attrs_,idi=0,cli=0,sti=0)
    def en(name): L[0]+=1; return dict(t=RES_XML_END_EL,line=L[0],ns=-1,name=ix(name))
    nodes=[dict(t=RES_XML_START_NS,line=1,prefix=ix('android'),uri=ANS)]
    nodes+=[st('selector',[]),st('item',[A('state_focused',0x12,0xffffffff)])]
    # element named 'shape' (index of attr string 'shape')
    L[0]+=1; nodes.append(dict(t=RES_XML_START_EL,line=L[0],ns=-1,name=ix('shape'),attrs=[A('shape',0x10,0)],idi=0,cli=0,sti=0))
    nodes+=[st('solid',[A('color',0x1c,0x26FFFFFF)]),en('solid')]
    nodes+=[st('stroke',[A('width',0x05,0x301),A('color',0x1c,0xFFFFFFFF)]),en('stroke')]
    nodes+=[st('corners',[A('radius',0x05,0x601)]),en('corners')]
    L[0]+=1; nodes.append(dict(t=RES_XML_END_EL,line=L[0],ns=-1,name=ix('shape')))
    nodes+=[en('item'),en('selector')]
    nodes.append(dict(t=RES_XML_END_NS,line=L[0]+1,prefix=ix('android'),uri=ANS))
    return build(pool,resmap,nodes)
if __name__=='__main__':
    out=make(); open('/home/claude/w/focus_selector.xml','wb').write(out)
    p,r,n=parse(out); print(dump(p,r,n)); print(len(out),[hex(x) for x in r])
