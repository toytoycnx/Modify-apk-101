import struct,sys,re
def uleb(d,p):
    r=0;s=0
    while True:
        b=d[p];p+=1;r|=(b&0x7f)<<s;s+=7
        if b<0x80:return r,p
class Dex:
    def __init__(s,path):
        d=s.d=open(path,'rb').read()
        (s.nstr,s.stroff)=struct.unpack_from('<II',d,56)
        s.ntype,s.typeoff=struct.unpack_from('<II',d,64)
        s.nproto,s.protooff=struct.unpack_from('<II',d,72)
        s.nmeth,s.methoff=struct.unpack_from('<II',d,88)
        s.nclass,s.classoff=struct.unpack_from('<II',d,96)
        s.strs=[None]*s.nstr
    def S(s,i):
        if s.strs[i] is None:
            o=struct.unpack_from('<I',s.d,s.stroff+4*i)[0]
            _,p=uleb(s.d,o); e=s.d.index(b'\0',p)
            s.strs[i]=s.d[p:e].decode('utf-8','replace')
        return s.strs[i]
    def T(s,i): return s.S(struct.unpack_from('<I',s.d,s.typeoff+4*i)[0])
    def M(s,i):
        c,pr,n=struct.unpack_from('<HHI',s.d,s.methoff+8*i); return s.T(c),s.S(n)
    def classes(s):
        for i in range(s.nclass):
            ci,af,sup,ifc,src,ann,cdata,sv=struct.unpack_from('<8I',s.d,s.classoff+32*i)
            yield s.T(ci),cdata
    def methods_code(s,cdata):
        d=s.d;p=cdata
        sf,p=uleb(d,p);inf,p=uleb(d,p);dm,p=uleb(d,p);vm,p=uleb(d,p)
        for _ in range(sf+inf): _,p=uleb(d,p);_,p=uleb(d,p)
        idx=0
        for cnt in(dm,vm):
            idx=0
            for _ in range(cnt):
                di,p=uleb(d,p);idx+=di;_,p=uleb(d,p);co,p=uleb(d,p)
                if co: yield idx,co
