import sys,struct; sys.path.insert(0,'/home/claude/w')
from dexscan import *
SZ={}
def setr(a,b,n):
    for i in range(a,b+1): SZ[i]=n
setr(0,0xff,1)
for a,n in [(0x02,2),(0x03,3),(0x05,2),(0x06,3),(0x08,2),(0x09,3),(0x13,2),(0x14,3),(0x15,2),(0x16,2),(0x17,3),(0x18,5),(0x19,2),(0x1a,2),(0x1b,3),(0x1c,2),(0x1f,2),(0x20,2),(0x22,2),(0x23,2),(0x24,3),(0x25,3),(0x26,3),(0x29,2),(0x2a,3),(0x2b,3),(0x2c,3)]: SZ[a]=n
setr(0x2d,0x31,2);setr(0x32,0x3d,2);setr(0x44,0x6d,2);setr(0x6e,0x72,3);setr(0x74,0x78,3);setr(0x90,0xaf,2);setr(0xd0,0xe2,2);SZ[0xfa]=4;SZ[0xfb]=4;SZ[0xfc]=3;SZ[0xfd]=3;SZ[0xfe]=2;SZ[0xff]=2
def dis(dx,co,want=None):
    d=dx.d
    regs,ins,outs,tries,dbg,isz=struct.unpack_from('<HHHHII',d,co)
    u=struct.unpack('<%dH'%isz,d[co+16:co+16+isz*2])
    i=0;out=[]
    while i<isz:
        w=u[i];op=w&0xff
        if w in(0x100,0x200,0x300) and op==0 :
            if w==0x100: n=4+u[i+1]*2
            elif w==0x200: n=2+u[i+1]*4
            else: n=4+(u[i+1]*u[i+2]+1)//2 if False else 4+((u[i+1]*u[i+2]+1)//2)
            out.append('%04x: <payload>'%i); i+=n; continue
        n=SZ[op]; t=None
        a=(w>>8)&0xf;b=(w>>12)&0xf;AA=w>>8
        if op in(0x6e,0x6f,0x70,0x71,0x72):
            c,m=dx.M(u[i+1]); t='invoke(%d) %s.%s args=%x'%(op-0x6e,c,m,u[i+2])
        elif op in(0x74,0x75,0x76,0x77,0x78):
            c,m=dx.M(u[i+1]); t='invoke/range %s.%s'%(c,m)
        elif op==0x1a: t='const-string v%d "%s"'%(AA,dx.S(u[i+1]))
        elif op==0x0a or op==0x0c: t='move-result v%d'%AA
        elif 0x38<=op<=0x3d: t='if-%s v%d -> %04x'%(['eqz','nez','ltz','gez','gtz','lez'][op-0x38],AA,i+struct.unpack('<h',struct.pack('<H',u[i+1]))[0])
        elif 0x32<=op<=0x37: t='if-%s v%d,v%d -> %04x'%(['eq','ne','lt','ge','gt','le'][op-0x32],a,b,i+struct.unpack('<h',struct.pack('<H',u[i+1]))[0])
        elif op==0x28: t='goto %04x'%(i+struct.unpack('<b',bytes([AA]))[0])
        elif op==0x0e: t='return-void'
        elif op in(0x54,0x55,0x56,0x57,0x58,0x59,0x5a): t='iget/iput v%d,v%d field#%d'%(a,b,u[i+1])
        elif op in(0x60,0x61,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6a,0x6b,0x6c,0x6d): t='sget/sput v%d field#%d'%(AA,u[i+1])
        elif op==0x22: t='new-instance v%d %s'%(AA,dx.T(u[i+1]))
        elif op==0x14: t='const v%d #0x%x'%(AA,u[i+1]|(u[i+2]<<16))
        elif op==0x15: t='const/high16 v%d #0x%x'%(AA,u[i+1]<<16)
        elif op in(0x2b,0x2c): t='%s-switch v%d payload@%04x'%('packed' if op==0x2b else 'sparse',AA,i+(u[i+1]|(u[i+2]<<16)))
        elif op in(0x12,): t='const/4 v%d #%d'%(a,b if b<8 else b-16)
        elif op==0x13: t='const/16 v%d #%d'%(AA,struct.unpack('<h',struct.pack('<H',u[i+1]))[0])
        else: t='op%02x'%op
        out.append('%04x: %s'%(i,t)); i+=n
    return out
def find(path_cls,mname=None,dexes=None):
    import glob
    for f in sorted(glob.glob('classes*.dex')):
        dx=Dex(f)
        for cname,cdata in dx.classes():
            if cname==path_cls and cdata:
                for mi,co in dx.methods_code(cdata):
                    if mname is None or dx.M(mi)[1]==mname:
                        yield dx,dx.M(mi)[1],co
