import axml, struct
from axml import *
d=open('AndroidManifest.xml','rb').read()
pool,resmap,nodes=parse(d)
S=pool.strings

def insert_attr_name(name,resid):
    """insert string at index len(resmap) so it's covered by resource map; shift refs"""
    pos=len(resmap)
    S.insert(pos,name); resmap.append(resid)
    def f(i): return i+1 if (i is not None and i>=pos) else i
    for n in nodes:
        t=n['t']
        if t==RES_XML_START_EL or t==RES_XML_END_EL:
            n['ns']=f(n['ns']) if n['ns']!=-1 else -1; n['name']=f(n['name'])
        if t==RES_XML_START_EL:
            for a in n['attrs']:
                a.ns=f(a.ns) if a.ns!=-1 else -1; a.name=f(a.name)
                if a.raw!=-1: a.raw=f(a.raw)
                if a.type==3: a.data=f(a.data)
        if t in(RES_XML_START_NS,RES_XML_END_NS):
            n['prefix']=f(n['prefix']); n['uri']=f(n['uri'])
    return pos

ANS=S.index(NS_ANDROID)
def sidx(v): return pool.idx(v)
def A(nm): return S.index(nm)  # attribute name idx (must exist)

banner=insert_attr_name('banner',0x010103f2)
ANS=S.index(NS_ANDROID)
def rid_of(a): return resmap[a.name] if a.name<len(resmap) else 1<<40

def mk_attr(name,typ,data,raw=-1):
    return Attr(ANS,S.index(name) if name in S[:len(resmap)] else sidx(name),raw,typ,data)

def get(n,name):
    for a in n['attrs']:
        if S[a.name]==name: return a

# 1. orientation: portrait(1) -> unspecified(-1)
cnt=0
for n in nodes:
    if n['t']==RES_XML_START_EL and S[n['name']]=='activity':
        a=get(n,'screenOrientation')
        if a and a.data==1: a.data=0xffffffff; cnt+=1
print('orientation patched:',cnt)

# 2. required=false on existing uses-feature + add banner
req=S.index('required')
def add_required(n):
    if get(n,'required') is None:
        a=Attr(ANS,req,-1,0x12,0)
        # after name
        i=[k for k,x in enumerate(n['attrs']) if S[x.name]=='name'][0]
        n['attrs'].insert(i+1,a)
for n in nodes:
    if n['t']==RES_XML_START_EL and S[n['name']]=='uses-feature': add_required(n)

# 3. add new uses-feature elements after camera.autofocus
def feature_nodes(fname,line):
    nm=S.index('name'); uf=sidx('uses-feature')
    st=dict(t=RES_XML_START_EL,line=line,ns=-1,name=uf,attrs=[
        Attr(ANS,nm,sidx(fname),3,sidx(fname)),Attr(ANS,req,-1,0x12,0)])
    en=dict(t=RES_XML_END_EL,line=line,ns=-1,name=uf)
    return [st,en]
idx=None
for k,n in enumerate(nodes):
    if n['t']==RES_XML_START_EL and S[n['name']]=='uses-feature':
        a=get(n,'name')
        if S[a.raw]=='android.hardware.camera.autofocus': idx=k
end=idx+1
assert nodes[end]['t']==RES_XML_END_EL
ins=[]
for f in ['android.hardware.touchscreen','android.software.leanback','android.hardware.microphone','android.hardware.telephony','android.hardware.location.gps','android.hardware.bluetooth']:
    ins+=feature_nodes(f,nodes[end]['line'])
nodes[end+1:end+1]=ins

# 4. application banner (reuse icon) + LEANBACK category on Splash
for n in nodes:
    if n['t']==RES_XML_START_EL and S[n['name']]=='application':
        icon=get(n,'icon')
        b=Attr(ANS,banner,-1,icon.type,icon.data)
        pos=len(n['attrs'])
        for k,a in enumerate(n['attrs']):
            if a.ns!=-1 and rid_of(a)>0x010103f2: pos=k;break
        n['attrs'].insert(pos,b)
splash=None
for k,n in enumerate(nodes):
    if n['t']==RES_XML_START_EL and S[n['name']]=='activity':
        a=get(n,'name')
        if S[a.raw].endswith('.SplashActivity'): splash=k
# find LAUNCHER category end
k=splash
while True:
    n=nodes[k]
    if n['t']==RES_XML_START_EL and S[n['name']]=='category':
        a=get(n,'name')
        if S[a.raw]=='android.intent.category.LAUNCHER': break
    k+=1
assert nodes[k+1]['t']==RES_XML_END_EL
cat=S.index('category'); nm=S.index('name')
lb='android.intent.category.LEANBACK_LAUNCHER'
st=dict(t=RES_XML_START_EL,line=nodes[k]['line'],ns=-1,name=cat,attrs=[Attr(ANS,nm,sidx(lb),3,sidx(lb))])
en=dict(t=RES_XML_END_EL,line=nodes[k]['line'],ns=-1,name=cat)
nodes[k+2:k+2]=[st,en]

out=build(pool,resmap,nodes)
open('AndroidManifest.patched.xml','wb').write(out)
# verify re-parse
p2,r2,n2=parse(out)
open('manifest_new.txt','w').write(dump(p2,r2,n2))
print('ok',len(d),'->',len(out))
