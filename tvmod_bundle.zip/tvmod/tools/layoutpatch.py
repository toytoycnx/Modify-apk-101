import sys,glob,os,pickle; sys.path.insert(0,'/home/claude/w')
import axml
from axml import *
FG=0x010100da and 0x01010109
RID_FOCUSABLE=0x010100da; RID_FOREGROUND=0x01010109
FOCUS_DRAWABLE=0x7f0800b7   # bg_home_special_list_item4 -> repurposed as focus selector

def shift_strings(pool,resmap,nodes,pos):
    def f(i): return i+1 if i>=pos else i
    for n in nodes:
        t=n['t']
        if t in(RES_XML_START_EL,RES_XML_END_EL):
            n['ns']=f(n['ns']) if n['ns']!=-1 else -1; n['name']=f(n['name'])
        if t==RES_XML_START_EL:
            for a in n['attrs']:
                a.ns=f(a.ns) if a.ns!=-1 else -1; a.name=f(a.name)
                if a.raw!=-1: a.raw=f(a.raw)
                if a.type==3: a.data=f(a.data)
        if t in(RES_XML_START_NS,RES_XML_END_NS):
            n['prefix']=f(n['prefix']); n['uri']=f(n['uri'])

def ensure_attr(pool,resmap,nodes,name,resid):
    S=pool.strings
    for i,r in enumerate(resmap):
        if r==resid and i<len(S): return i
    pos=len(resmap)
    S.insert(pos,name); resmap.append(resid)
    shift_strings(pool,resmap,nodes,pos)
    return pos

def key_of(a,resmap,ANS):
    if a.ns==ANS and a.name<len(resmap): return resmap[a.name]
    return 1<<40

def fix_idx(n,S):
    idi=cli=sti=0
    for k,a in enumerate(n['attrs']):
        nm=S[a.name]
        if a.ns!=-1 and nm=='id' and S[a.ns]==NS_ANDROID: idi=k+1
        if a.ns==-1 and nm=='class': cli=k+1
        if a.ns==-1 and nm=='style': sti=k+1
    n['idi'],n['cli'],n['sti']=idi,cli,sti

def get(n,S,name):
    for a in n['attrs']:
        if S[a.name]==name and (a.ns==-1 or S[a.ns]==NS_ANDROID): return a

def add_attr(n,resmap,ANS,idx,typ,data,S):
    a=Attr(ANS,idx,-1,typ,data)
    k=key_of(a,resmap,ANS); pos=len(n['attrs'])
    for j,x in enumerate(n['attrs']):
        if key_of(x,resmap,ANS)>k: pos=j; break
    n['attrs'].insert(pos,a); fix_idx(n,S)
