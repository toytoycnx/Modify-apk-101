import struct
RES_STRING_POOL=0x0001; RES_XML=0x0003; RES_XML_START_NS=0x100; RES_XML_END_NS=0x101
RES_XML_START_EL=0x102; RES_XML_END_EL=0x103; RES_XML_CDATA=0x104; RES_XML_RESMAP=0x180
NS_ANDROID="http://schemas.android.com/apk/res/android"

class StringPool:
    def __init__(s, data, off):
        (t,hs,size,n,ns,flags,sstart,ststart)=struct.unpack_from('<HHIIIIII',data,off)
        s.utf8=bool(flags&0x100); s.flags=flags
        offs=struct.unpack_from('<%dI'%n,data,off+hs)
        s.strings=[]
        base=off+sstart
        for o in offs:
            p=base+o
            if s.utf8:
                l=data[p]; p+=1
                if l&0x80: l=((l&0x7f)<<8)|data[p]; p+=1
                bl=data[p]; p+=1
                if bl&0x80: bl=((bl&0x7f)<<8)|data[p]; p+=1
                s.strings.append(data[p:p+bl].decode('utf-8','surrogatepass'))
            else:
                l=struct.unpack_from('<H',data,p)[0]; p+=2
                if l&0x8000:
                    l=((l&0x7fff)<<16)|struct.unpack_from('<H',data,p)[0]; p+=2
                s.strings.append(data[p:p+l*2].decode('utf-16le','surrogatepass'))
        s.size=size
    def serialize(s):
        body=bytearray(); offs=[]
        for st in s.strings:
            offs.append(len(body))
            if s.utf8:
                b=st.encode('utf-8','surrogatepass')
                def ln(x): return bytes([x]) if x<0x80 else bytes([0x80|(x>>8),x&0xff])
                body+=ln(len(st))+ln(len(b))+b+b'\0'
            else:
                u=st.encode('utf-16le','surrogatepass'); l=len(u)//2
                body+=(struct.pack('<H',l) if l<0x8000 else struct.pack('<HH',0x8000|(l>>16),l&0xffff))+u+b'\0\0'
        while len(body)%4: body+=b'\0'
        hs=28; sstart=hs+4*len(offs)
        size=sstart+len(body)
        return struct.pack('<HHIIIIII',RES_STRING_POOL,hs,size,len(offs),0,s.flags,sstart,0)+struct.pack('<%dI'%len(offs),*offs)+bytes(body)
    def idx(s,v):
        if v in s.strings: return s.strings.index(v)
        s.strings.append(v); return len(s.strings)-1

class Attr:
    def __init__(s,ns,name,raw,typ,data): s.ns=ns;s.name=name;s.raw=raw;s.type=typ;s.data=data

def parse(data):
    t,hs,size=struct.unpack_from('<HHI',data,0)
    assert t==RES_XML
    off=hs; pool=None; resmap=[]; nodes=[]
    while off<size:
        t,hs,sz=struct.unpack_from('<HHI',data,off)
        if t==RES_STRING_POOL: pool=StringPool(data,off)
        elif t==RES_XML_RESMAP: resmap=list(struct.unpack_from('<%dI'%((sz-hs)//4),data,off+hs))
        else:
            line,cmt=struct.unpack_from('<II',data,off+8)
            if t==RES_XML_START_EL:
                ns,name,astart,asz,ac,idi,cli,sti=struct.unpack_from('<iiHHHHHH',data,off+16)
                attrs=[]
                ap=off+16+astart
                for i in range(ac):
                    a=struct.unpack_from('<iiiHBBI',data,ap+i*20)
                    attrs.append(Attr(a[0],a[1],a[2],a[4]if False else a[4],a[6]) if False else Attr(a[0],a[1],a[2],a[5],a[6]))
                nodes.append(dict(t=t,line=line,ns=ns,name=name,attrs=attrs,idi=idi,cli=cli,sti=sti))
            elif t==RES_XML_END_EL:
                ns,name=struct.unpack_from('<ii',data,off+16)
                nodes.append(dict(t=t,line=line,ns=ns,name=name))
            elif t in(RES_XML_START_NS,RES_XML_END_NS):
                prefix,uri=struct.unpack_from('<ii',data,off+16)
                nodes.append(dict(t=t,line=line,prefix=prefix,uri=uri))
            else:
                nodes.append(dict(t=t,raw=data[off:off+sz]))
        off+=sz
    return pool,resmap,nodes

def build(pool,resmap,nodes):
    out=bytearray()
    out+=pool.serialize()
    out+=struct.pack('<HHI',RES_XML_RESMAP,8,8+4*len(resmap))+struct.pack('<%dI'%len(resmap),*resmap)
    for n in nodes:
        t=n['t']
        if t==RES_XML_START_EL:
            at=n['attrs']
            sz=36+20*len(at)
            out+=struct.pack('<HHIII',t,16,sz,n['line'],0xffffffff)
            out+=struct.pack('<iiHHHHHH',n['ns'],n['name'],20,20,len(at),n.get('idi',0),n.get('cli',0),n.get('sti',0))
            for a in at:
                out+=struct.pack('<iiiHBBI',a.ns,a.name,a.raw,8,0,a.type,a.data&0xffffffff)
        elif t==RES_XML_END_EL:
            out+=struct.pack('<HHIII',t,16,24,n['line'],0xffffffff)+struct.pack('<ii',n['ns'],n['name'])
        elif t in(RES_XML_START_NS,RES_XML_END_NS):
            out+=struct.pack('<HHIII',t,16,24,n['line'],0xffffffff)+struct.pack('<ii',n['prefix'],n['uri'])
        else: out+=n['raw']
    return struct.pack('<HHI',RES_XML,8,8+len(out))+bytes(out)

def dump(pool,resmap,nodes):
    S=pool.strings; depth=0; lines=[]
    for n in nodes:
        if n['t']==RES_XML_START_EL:
            nm=S[n['name']]
            parts=[]
            for a in n['attrs']:
                an=S[a.name]; pre='android:' if a.ns!=-1 and S[a.ns]==NS_ANDROID else ''
                if a.type==3: v=S[a.raw]
                elif a.type==0x12: v='true' if a.data else 'false'
                elif a.type==0x10: v=str(a.data if a.data<2**31 else a.data-2**32)
                elif a.type==1: v='@0x%08x'%a.data
                elif a.type==0x11: v='0x%x'%a.data
                else: v='<t%x:0x%x>'%(a.type,a.data)
                parts.append('%s%s="%s"'%(pre,an,v))
            lines.append('  '*depth+'<'+nm+(' '+' '.join(parts) if parts else '')+'>'); depth+=1
        elif n['t']==RES_XML_END_EL:
            depth-=1; lines.append('  '*depth+'</'+S[n['name']]+'>')
    return '\n'.join(lines)
