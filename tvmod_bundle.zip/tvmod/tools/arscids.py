import sys,struct; sys.path.insert(0,'/home/claude/w')
import axml
d=open('/home/claude/w/res/resources.arsc','rb').read()
off=12
chunks=[]
while off<len(d):
    t,hs,sz=struct.unpack_from('<HHI',d,off); chunks.append((t,off,sz)); off+=sz
pk=[c for c in chunks if c[0]==0x200][0]; po=pk[1]
pid=struct.unpack_from('<I',d,po+8)[0]; typeStrings,lastPT,keyStrings,lastPK=struct.unpack_from('<IIII',d,po+8+4+256)
tsp=axml.StringPool(d,po+typeStrings); ksp=axml.StringPool(d,po+keyStrings)
def ids():
    o=po+struct.unpack_from('<H',d,po+2)[0]; end=po+pk[2]
    out={}
    while o<end:
        t,hs,sz=struct.unpack_from('<HHI',d,o)
        if t==0x201:
            tid=d[o+8]; ec=struct.unpack_from('<I',d,o+12)[0]; es=struct.unpack_from('<I',d,o+16)[0]
            offs=struct.unpack_from('<%dI'%ec,d,o+hs)
            for i,eo in enumerate(offs):
                if eo==0xffffffff: continue
                ep=o+es+eo; key=struct.unpack_from('<I',d,ep+4)[0]
                out[(tsp.strings[tid-1],ksp.strings[key])]=(pid<<24)|(tid<<16)|i
        o+=sz
    return out
