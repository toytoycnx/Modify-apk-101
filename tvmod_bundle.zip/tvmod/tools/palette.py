# new theme: "Midnight Violet"   (name -> new ARGB)
NEW={
 'theme_bg_color':0xff0b1020,
 'main_tab_bg':0xff121a2e, 'color_home_but_bg':0xff121a2e,
 'color_272b30':0xff182139, 'color_home_gusslike_bg':0xff182139, 'color_1b202b':0xff151d33,
 'color_202023':0xff141b2f, 'color_292a2f':0xff1a2238, 'color_38383A':0xff222c48,
 'color_commen_editbg':0xff222c48, 'color_bg_setlanguage_top':0xff1c2540,
 'color_vertical_line':0xff2e3a5c, 'color_actionbar_line':0xff1f2840,
 'color_commen':0xff7c5cff, 'color_commen_pressed':0xffa18cff, 'color_commen_80':0xcc7c5cff,
 'color_0feb33':0xff7c5cff, 'color_1c454c':0xff5a3fd1,
 'color_main_tab_nor':0xff8b94ad, 'color_item_text_mormal':0xff7a86a6,
}
