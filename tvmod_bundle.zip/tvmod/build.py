import os, zipfile, struct, hashlib, base64, datetime, sys, io
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.serialization import pkcs7

HERE=os.path.dirname(os.path.abspath(__file__))
if len(sys.argv)!=4: sys.exit('usage: python build.py <original.apk> <AndroidManifest.target34.xml|target33.xml> <output.apk>')
SRC,MANIFEST,OUT=sys.argv[1],sys.argv[2],sys.argv[3]
newman=open(MANIFEST,'rb').read()
import zlib,binascii
import glob
REPL={}
for pth in glob.glob(os.path.join(HERE,'patches','**','*'),recursive=True):
    if os.path.isfile(pth): REPL[os.path.relpath(pth,os.path.join(HERE,'patches')).replace(os.sep,'/')]=open(pth,'rb').read()

kp=os.path.join(HERE,'sign_key.pem'); cp=os.path.join(HERE,'sign_cert.der')
if not (os.path.exists(kp) and os.path.exists(cp)): sys.exit('sign_key.pem / sign_cert.der not found - without them the APK cannot be installed over the old one')
key=serialization.load_pem_private_key(open(kp,'rb').read(),None)
cert=x509.load_der_x509_certificate(open(cp,'rb').read())
cert_der=cert.public_bytes(serialization.Encoding.DER)

zf=zipfile.ZipFile(SRC); raw=open(SRC,'rb')
def is_sig(n):
    u=n.upper()
    return u=='META-INF/MANIFEST.MF' or (u.startswith('META-INF/') and u.count('/')==1 and (u.endswith(('.SF','.RSA','.DSA','.EC')) or u.startswith('META-INF/SIG-')))
entries=[]  # dict(name, zi-like info, comp, crc, csize, usize, data(raw), plain(for hashing))
for zi in zf.infolist():
    if zi.is_dir() or is_sig(zi.filename): continue
    if zi.filename=='AndroidManifest.xml':
        plain=newman; data=newman; comp=0
        crc=zipfile.crc32(newman) if hasattr(zipfile,'crc32') else __import__('binascii').crc32(newman)
        e=dict(name=zi.filename,comp=0,crc=crc&0xffffffff,csize=len(data),usize=len(data),data=data,plain=plain,dt=zi.date_time)
    elif zi.filename in REPL:
        pl=REPL[zi.filename]
        if zi.filename=='resources.arsc': cz=pl; cm=0
        else:
            co=zlib.compressobj(9,zlib.DEFLATED,-15); cz=co.compress(pl)+co.flush(); cm=8
        e=dict(name=zi.filename,comp=cm,crc=binascii.crc32(pl)&0xffffffff,csize=len(cz),usize=len(pl),data=cz,plain=pl,dt=zi.date_time)
    else:
        raw.seek(zi.header_offset); h=raw.read(30)
        nl,el=struct.unpack('<HH',h[26:30]); raw.seek(zi.header_offset+30+nl+el)
        data=raw.read(zi.compress_size)
        e=dict(name=zi.filename,comp=zi.compress_type,crc=zi.CRC,csize=zi.compress_size,usize=zi.file_size,data=data,plain=zf.read(zi.filename),dt=zi.date_time)
    entries.append(e)
print(len(entries),'entries'); missing=[k for k in REPL if k not in {e['name'] for e in entries}]; print('REPL files:',len(REPL),'missing in apk:',missing); assert not missing

# ---- v1 signing
def wrap(line):
    b=line.encode(); out=[]; first=True
    while len(b)>(72 if first else 71):
        n=72 if first else 71; out.append(b[:n]); b=b[n:]; first=False
    out.append(b)
    return b'\r\n '.join(out)+b'\r\n'
def b64(x): return base64.b64encode(x).decode()
mf=b'Manifest-Version: 1.0\r\nCreated-By: 1.0 (Android)\r\n\r\n'
sections=[]
for e in entries:
    s=wrap('Name: '+e['name'])+wrap('SHA-256-Digest: '+b64(hashlib.sha256(e['plain']).digest()))+b'\r\n'
    sections.append(s); mf+=s
sf=(b'Signature-Version: 1.0\r\nCreated-By: 1.0 (Android)\r\n'+wrap('SHA-256-Digest-Manifest: '+b64(hashlib.sha256(mf).digest()))+b'X-Android-APK-Signed: 2\r\n\r\n')
for e,s in zip(entries,sections):
    sf+=wrap('Name: '+e['name'])+wrap('SHA-256-Digest: '+b64(hashlib.sha256(s).digest()))+b'\r\n'
rsa_blob=(pkcs7.PKCS7SignatureBuilder().set_data(sf).add_signer(cert,key,hashes.SHA256())
          .sign(serialization.Encoding.DER,[pkcs7.PKCS7Options.DetachedSignature,pkcs7.PKCS7Options.Binary]))
def meta(n,b):
    return dict(name=n,comp=0,crc=__import__('binascii').crc32(b)&0xffffffff,csize=len(b),usize=len(b),data=b,plain=b,dt=(2026,1,1,0,0,0))
meta_entries=[meta('META-INF/MANIFEST.MF',mf),meta('META-INF/TVMOD.SF',sf),meta('META-INF/TVMOD.RSA',rsa_blob)]
allent=meta_entries+entries

# ---- write zip with alignment
buf=io.BytesIO(); cd=bytearray()
def dos(dt):
    y,mo,d,h,mi,s=dt
    return ((h<<11)|(mi<<5)|(s//2)), (((y-1980)<<9)|(mo<<5)|d)
for e in allent:
    nb=e['name'].encode(); flags=0x800 if any(ord(c)>127 for c in e['name']) else 0
    off=buf.tell()
    extra=b''
    if e['comp']==0:
        al=4096 if e['name'].endswith('.so') else 4
        start=off+30+len(nb)
        pad=(-start)%al
        if 0<pad<4: pad+=al
        if pad: extra=struct.pack('<HH',0xD935,pad-4)+b'\0'*(pad-4)
    t,d=dos(e['dt'])
    ver=20 if e['comp'] else 10
    buf.write(struct.pack('<IHHHHHIIIHH',0x04034b50,ver,flags,e['comp'],t,d,e['crc'],e['csize'],e['usize'],len(nb),len(extra))+nb+extra+e['data'])
    cd+=struct.pack('<IHHHHHHIIIHHHHHII',0x02014b50,ver,ver,flags,e['comp'],t,d,e['crc'],e['csize'],e['usize'],len(nb),0,0,0,0,0,off)+nb
entries_bytes=buf.getvalue()
cd=bytes(cd); n=len(allent)
def eocd(cd_off): return struct.pack('<IHHHHIIH',0x06054b50,0,0,n,n,len(cd),cd_off,0)

# ---- v2 signing
CH=1<<20
def chunks(b): return [b[i:i+CH] for i in range(0,len(b),CH)] or [b'']
digs=[]
for sec in (entries_bytes,cd,eocd(len(entries_bytes))):
    for c in chunks(sec): digs.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
top=hashlib.sha256(b'\x5a'+struct.pack('<I',len(digs))+b''.join(digs)).digest()
def lp(b): return struct.pack('<I',len(b))+b
algo=0x0103
digests=lp(struct.pack('<I',algo)+lp(top))
signed_data=lp(digests)+lp(lp(cert_der))+lp(b'')
sig=key.sign(signed_data,padding.PKCS1v15(),hashes.SHA256())
pub=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
signer=lp(signed_data)+lp(lp(struct.pack('<I',algo)+lp(sig)))+lp(pub)
v2=lp(lp(signer))
pair=struct.pack('<QI',len(v2)+4,0x7109871a)+v2
blk_size=len(pair)+8+16
block=struct.pack('<Q',blk_size)+pair+struct.pack('<Q',blk_size)+b'APK Sig Block 42'
final=entries_bytes+block+cd+eocd(len(entries_bytes)+len(block))
_d=os.path.dirname(os.path.abspath(OUT)); os.makedirs(_d,exist_ok=True)
open(OUT,'wb').write(final)
print('written',len(final))
